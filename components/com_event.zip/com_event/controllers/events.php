<?php
/**
 * @version     1.0.0
 * @package     com_events
 * @copyright   Copyright (C) 2013. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      yogendra <yogendra.singh@daffodilsw.com> - http://
 */

// No direct access.
defined('_JEXEC') or die;

require_once JPATH_COMPONENT.'/controller.php';

/**
 * Events list controller class.
 */
class EventControllerEvents extends EventController
{  
   public function __construct($config = array())
    {   
      // $user = JFactory::getUser(); 
       parent::__construct($config);
    }
	/**
	 * Proxy for getModel.
	 * @since	1.6
	 */
	public function &getModel($name = 'Events', $prefix = 'EventModel')
	{
		$model = parent::getModel($name, $prefix, array('ignore_request' => true));
		return $model;
	}
 /*
   * function for searching friends.......
   */	
//	public function searchfriend()
//	{
//	     $friend = JRequest::getVar('searchfriend');
//	     $model = $this->getModel();
//         $mainframe = JFactory::getApplication();
//         // Get pagination request variables
//         $limit = $mainframe->getUserStateFromRequest('global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
// 	     $model->setState('limit', JRequest::getVar('limit', $limit, '', 'int'));
//	     $model->setState('limitstart', JRequest::getVar('limitstart', 0, '', 'int'));
//		 $this->result = $model->getFriends($friend); 
//		 $this->_total = count($this->result); 
//	     if ($model->getState('limit') > 0) {
//	       $this->result    = array_splice($this->result , $model->getState('limitstart'), $model->getState('limit'));
//	     }	 
//	    jimport('joomla.html.pagination'); 
//	    $this->_pagination = new JPagination($this->_total, $model->getState('limitstart'), $model->getState('limit') );
//	    $pagination = $this->_pagination;  
//		$view = $this->getView('Myfriendss', 'html');
//		$view->assign('items', $this->result);
//		$view->assign('pagination', $pagination);
//	    $view->setLayout('friends');
//	    $view->friends();
//	}
}